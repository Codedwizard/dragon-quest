License
=======
- Code	WTFPL
- Texture	CC
