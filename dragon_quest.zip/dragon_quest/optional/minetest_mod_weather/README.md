# Weather mod for [Minetest](http://minetest.net/)

Luacheck: [![Luacheck Status](https://travis-ci.org/theFox6/minetest_mod_weather.svg?branch=master)](https://travis-ci.org/theFox6/minetest_mod_weather)

License:
- Code: LGPL
- Textures:
  - Snow cover: WTFPL
  - Rain / Snow: CC-BY-SA 3.0, credit goes to TeddyDesTodes, from his weather branch at https://github.com/TeddyDesTodes/minetest/tree/weather
